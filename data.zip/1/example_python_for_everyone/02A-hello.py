# Hello!를 두 번 화면에 출력하는 프로그램
# 각 줄의 샵(#) 이후는 설명 부분입니다.
# 설명 부분은 읽어 본 후 입력하지 않아도 됩니다.
print("Hello!")         # print는 소문자로 입력
print("Hello!")         # Hello!를 두 번 표시
while True:
    print('inf')