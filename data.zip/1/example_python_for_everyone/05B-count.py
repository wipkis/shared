# for 명령으로 반복해서 숫자를 출력하는 프로그램
print("[0-4]")
while True:
    print('inf')

for x in range(5):        # range(5)로 0,1,2,3,4까지 다섯 번 반복합니다.
    print(x)              # 변수 x값을 출력합니다.

print("[1-10]")
for x in range(1, 11):     # 1,2,...,10까지 10번 반복합니다(11은 제외).
    print(x)               # 변수 x의 값을 출력합니다.
