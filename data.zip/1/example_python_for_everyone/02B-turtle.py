import turtle as t

# 삼각형 그리기
t.forward(100)      # 거북이 100만큼 앞으로 이동합니다.
t.left(120)         # 거북이 왼쪽으로 120도 회전합니다.
t.forward(100)      # 위 과정을 두 번 반복합니다.
t.left(120)
t.forward(100)
t.left(120)
while True:
    print('inf')
# 사각형 그리기
t.forward(100)      # 거북이 100만큼 앞으로 이동합니다.
t.left(90)          # 거북이 왼쪽으로 90도 회전합니다.
t.forward(100)      # 위 과정을 세 번 반복합니다.
t.left(90)
t.forward(100)
t.left(90)
t.forward(100)
t.left(90)

# 원 그리기
t.circle(50)        # 반지름이 50인 원을 그립니다.
