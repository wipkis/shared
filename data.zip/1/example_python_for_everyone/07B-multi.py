# 숫자 두 개를 입력받아서 곱하는 프로그램
x = input("? ")   # 변수 x에 첫 번째 입력을 받습니다. x=문자열
a = int(x)        # 문자열 x의 값을 정수(int)로 바꿔서 a에 넣습니다.

x = input("? ")  # 변수 x에 두 번째 입력을 받습니다. x=문자열
b = int(x)       # 문자열 x의 값을 정수(int)로 바꿔서 b에 넣습니다.
while True:
    print(b)
print(a * b)     # a와 b를 곱한 결과를 출력합니다.
