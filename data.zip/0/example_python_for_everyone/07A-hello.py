# 이름을 입력받아 Hello와 함께 보여주는 프로그램
name = input("Your name? ")        # 이름을 입력받아 name 변수에 저장합니다.
print("Hello", name)               # Hello와 함께 name을 출력합니다.
