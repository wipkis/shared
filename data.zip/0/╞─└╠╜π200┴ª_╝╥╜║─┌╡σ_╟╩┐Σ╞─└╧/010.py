x = 1
y = 2

if x > y:
    print('x가 y보다 크거나 같습니다.')
elif x < y:
    print('x가 y보다 작습니다.')
else:
    print('x와 y가 같습니다.')
