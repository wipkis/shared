a = 107
b = (a>>4) & 0x0f
print(b)    # 6이 출력됨
