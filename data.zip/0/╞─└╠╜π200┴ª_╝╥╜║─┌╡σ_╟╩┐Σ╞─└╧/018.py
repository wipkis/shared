c1 = 1+7j
print(c1.real); print(c1.imag)
c2 = complex(2, 3)
print(c2)
