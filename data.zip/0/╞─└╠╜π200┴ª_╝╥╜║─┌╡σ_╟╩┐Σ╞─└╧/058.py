try:
   print(param)
except Exception as e:
   print(e)        # name 'param' is not defined 가 출력됨
