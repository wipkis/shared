try:
   print('안녕하세요.')
   print(param)
except:
   print('예외가 발생했습니다!')
finally:
   print('무조건 실행하는 코드')
