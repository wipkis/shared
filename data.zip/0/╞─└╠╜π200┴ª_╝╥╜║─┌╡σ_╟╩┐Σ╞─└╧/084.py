txt1 = 'A'
txt2 = '안녕'
txt3 = 'Warcraft Three'
txt4 = '3PO'
ret1 = txt1.isalpha()
ret2 = txt2.isalpha()
ret3 = txt3.isalpha()
ret4 = txt4.isalpha()
print(ret1)        # True가 출력됨
print(ret2)        # True가 출력됨
print(ret3)        # False가 출력됨
print(ret4)        # False가 출력됨
