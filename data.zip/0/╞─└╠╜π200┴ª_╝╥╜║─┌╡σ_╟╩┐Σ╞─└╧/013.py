scope = [1, 2, 3]
for x in scope:
    print(x)
else:
    print('Perfect')
