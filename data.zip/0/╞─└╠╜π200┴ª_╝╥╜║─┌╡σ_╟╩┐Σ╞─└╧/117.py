namelist = ['Mary', 'Sams', 'Aemy', 'Tom', 'Michale', 'Bob', 'Kelly']
namelist.sort()
print(namelist)
