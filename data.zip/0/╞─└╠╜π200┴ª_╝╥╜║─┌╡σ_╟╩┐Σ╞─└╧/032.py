listdata =[1, 2, 3, 4]
ret1 = 5 in listdata    # False
ret2 = 4 in listdata    # True
print(ret1); print(ret2)
strdata = 'abcde'
ret3 = 'c' in strdata    # True
ret4 = '1' in strdata    # False
print(ret3); print(ret4)
