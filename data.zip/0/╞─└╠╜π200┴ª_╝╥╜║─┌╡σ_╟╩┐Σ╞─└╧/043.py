import time

print('5초간 프로그램을 정지합니다.')
time.sleep(5)
print('5초가 지나갔습니다.')
