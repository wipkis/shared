txt = 'aAbBcCdDeEfFgGhHiIjJkK'
ret = txt[::2]
print(ret)       # ‘abcdefghijk’ 가 출력됨
